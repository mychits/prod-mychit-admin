import React from 'react'

const LoanReport = () => {
  return (
    <div>LoanReport</div>
  )
}

export default LoanReport