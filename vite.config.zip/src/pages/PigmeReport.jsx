import React from 'react'

const PigmeReport = () => {
  return (
    <div>PigmeReport</div>
  )
}

export default PigmeReport