const dataPaymentsFor={
    typeChit:"chits",
    typeLoan:"loans",
    typePigme:"pigme"
}
export default dataPaymentsFor