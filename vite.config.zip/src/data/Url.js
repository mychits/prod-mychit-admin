//const url = "http://localhost:3000/api";
const url = "http://51.21.197.152:3000/api";
export default url;
